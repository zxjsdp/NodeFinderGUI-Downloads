Version History
===============

Version v0.4.7
--------------

* FEATURE: Display valid calibration configs

Version v0.4.6
--------------

* BUGFIX: Fix display insertion point for 20 char width bug

Version v0.4.5
--------------

* FEATURE: Add read and save config file buttons
* FEATURE: Add menubar and menu items

Version v0.4.4
--------------

* FEATURE: Add right click menu for most of the text are

Version v0.4.3
--------------

* IMPROVE: Remove unnecessary logic, improve performance
* BUGFIX: Fix save as button for outcome and log

Version v0.4.2
--------------

* IMPROVE: Add screenshot to GitHub

Version v0.4.1
--------------

* FEATURE: First public preview release.
* BUGFIX: Fixed Python 3 compatibility.
